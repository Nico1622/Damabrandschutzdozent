(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/assets/TypeScript/_module/smoothScroll.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SmoothScroll,
    "getLenis",
    ()=>getLenis
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lenis$2f$dist$2f$lenis$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lenis/dist/lenis.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
let lenis = null;
const getLenis = ()=>lenis;
function SmoothScroll() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const rafIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const anchorHandlersRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const textareaHandlersRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SmoothScroll.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            if (!lenis) {
                lenis = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lenis$2f$dist$2f$lenis$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]({
                    duration: 1.35,
                    easing: {
                        "SmoothScroll.useEffect": (t)=>Math.min(1, 1.001 - Math.pow(2, -10 * t))
                    }["SmoothScroll.useEffect"],
                    smoothWheel: true
                });
                // RAF Loop - nur einmal starten
                const raf = {
                    "SmoothScroll.useEffect.raf": (time)=>{
                        lenis === null || lenis === void 0 ? void 0 : lenis.raf(time);
                        if (rafIdRef.current !== null) {
                            rafIdRef.current = requestAnimationFrame(raf);
                        }
                    }
                }["SmoothScroll.useEffect.raf"];
                rafIdRef.current = requestAnimationFrame(raf);
            }
            // Cleanup alte Handler
            anchorHandlersRef.current.forEach({
                "SmoothScroll.useEffect": (handler, el)=>{
                    el.removeEventListener("click", handler);
                }
            }["SmoothScroll.useEffect"]);
            anchorHandlersRef.current.clear();
            textareaHandlersRef.current.forEach({
                "SmoothScroll.useEffect": (handler, el)=>{
                    el.removeEventListener("input", handler);
                }
            }["SmoothScroll.useEffect"]);
            textareaHandlersRef.current.clear();
            // Neue Anchor-Scroll Handler
            document.querySelectorAll('a[href^="#"]').forEach({
                "SmoothScroll.useEffect": (a)=>{
                    const handler = {
                        "SmoothScroll.useEffect.handler": (e)=>{
                            const href = a.getAttribute("href");
                            if (!href || href === "#") return;
                            const targetEl = document.querySelector(href);
                            if (!targetEl) return;
                            e.preventDefault();
                            const rootStyles = getComputedStyle(document.documentElement);
                            const navHeightVar = rootStyles.getPropertyValue("--navigation-height").trim();
                            const navHeight = parseFloat(navHeightVar) || 0;
                            lenis === null || lenis === void 0 ? void 0 : lenis.scrollTo(targetEl, {
                                offset: -navHeight,
                                duration: 1.45,
                                easing: {
                                    "SmoothScroll.useEffect.handler": (t)=>1 - Math.pow(1 - t, 3)
                                }["SmoothScroll.useEffect.handler"],
                                onComplete: {
                                    "SmoothScroll.useEffect.handler": ()=>history.replaceState(null, "", href)
                                }["SmoothScroll.useEffect.handler"]
                            });
                        }
                    }["SmoothScroll.useEffect.handler"];
                    a.addEventListener("click", handler);
                    anchorHandlersRef.current.set(a, handler);
                }
            }["SmoothScroll.useEffect"]);
            // Textarea Scroll-Prevention
            document.querySelectorAll("textarea").forEach({
                "SmoothScroll.useEffect": (t)=>{
                    const handler = {
                        "SmoothScroll.useEffect.handler": ()=>{
                            if (t.scrollHeight > t.clientHeight) {
                                t.setAttribute("data-lenis-prevent", "");
                            } else {
                                t.removeAttribute("data-lenis-prevent");
                            }
                        }
                    }["SmoothScroll.useEffect.handler"];
                    handler();
                    t.addEventListener("input", handler);
                    textareaHandlersRef.current.set(t, handler);
                }
            }["SmoothScroll.useEffect"]);
            // Back-to-top Button
            const btt = document.querySelector(".back-to-top");
            if (btt) {
                const bttHandler = {
                    "SmoothScroll.useEffect.bttHandler": (e)=>{
                        e.preventDefault();
                        lenis === null || lenis === void 0 ? void 0 : lenis.scrollTo(0, {
                            duration: 2.25,
                            easing: {
                                "SmoothScroll.useEffect.bttHandler": (t)=>1 - Math.pow(1 - t, 4)
                            }["SmoothScroll.useEffect.bttHandler"]
                        });
                    }
                }["SmoothScroll.useEffect.bttHandler"];
                btt.addEventListener("click", bttHandler);
                anchorHandlersRef.current.set(btt, bttHandler);
            }
            return ({
                "SmoothScroll.useEffect": ()=>{
                    anchorHandlersRef.current.forEach({
                        "SmoothScroll.useEffect": (handler, el)=>{
                            el.removeEventListener("click", handler);
                        }
                    }["SmoothScroll.useEffect"]);
                    textareaHandlersRef.current.forEach({
                        "SmoothScroll.useEffect": (handler, el)=>{
                            el.removeEventListener("input", handler);
                        }
                    }["SmoothScroll.useEffect"]);
                }
            })["SmoothScroll.useEffect"];
        }
    }["SmoothScroll.useEffect"], [
        pathname
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SmoothScroll.useEffect": ()=>{
            return ({
                "SmoothScroll.useEffect": ()=>{
                    if (lenis) {
                        lenis.destroy();
                        lenis = null;
                    }
                    if (rafIdRef.current !== null) {
                        cancelAnimationFrame(rafIdRef.current);
                    }
                }
            })["SmoothScroll.useEffect"];
        }
    }["SmoothScroll.useEffect"], []);
    return null;
}
_s(SmoothScroll, "95mHW7N9JF8kZvHpRYtey9Mjugs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = SmoothScroll;
var _c;
__turbopack_context__.k.register(_c, "SmoothScroll");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/_essentials/basics.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleLogoScroll",
    ()=>handleLogoScroll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$_module$2f$smoothScroll$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/_module/smoothScroll.tsx [app-client] (ecmascript)"); // Pfad ggf. anpassen
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const handleLogoScroll = (e, pathname)=>{
    if (pathname === "/") {
        e.preventDefault();
        const lenis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$_module$2f$smoothScroll$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLenis"])();
        if (lenis) {
            // Nutzt Lenis für den identischen Smooth-Scroll wie dein BackToTop-Button
            lenis.scrollTo(0, {
                duration: 1.2,
                easing: (t)=>Math.min(1, 1.001 - Math.pow(2, -10 * t))
            });
        } else {
            // Fallback für Browser ohne aktives Smooth-Scroll Modul
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        }
    }
};
const Basics = ()=>{
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Basics.useEffect": ()=>{
            const html = document.documentElement;
            // --- 1. Browser & Device Detection ---
            const applyDeviceClasses = {
                "Basics.useEffect.applyDeviceClasses": ()=>{
                    const ua = navigator.userAgent;
                    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua);
                    const isChrome = /Chrome/i.test(ua) && !/Edg/i.test(ua);
                    const isFirefox = /Firefox/i.test(ua);
                    const isSafari = /^((?!chrome|android|crios|fxios|safari).)*safari/i.test(ua);
                    const isEdge = /Edg/i.test(ua);
                    // Grundklassen für Desktop/Mobil
                    html.classList.add(isMobile ? "mobile" : "desktop");
                    // Browser-spezifische Klassen für CSS-Fixes
                    if (isChrome) html.classList.add("chrome");
                    else if (isFirefox) html.classList.add("firefox");
                    else if (isSafari) html.classList.add("safari");
                    else if (isEdge) html.classList.add("edge");
                }
            }["Basics.useEffect.applyDeviceClasses"];
            // --- 2. Breakpoint Logic ---
            const breakpoints = {
                tiny: Number.parseInt(getComputedStyle(html).getPropertyValue("--break-tiny"), 10) || 0,
                small: Number.parseInt(getComputedStyle(html).getPropertyValue("--break-small"), 10) || 480,
                medium: Number.parseInt(getComputedStyle(html).getPropertyValue("--break-medium"), 10) || 768,
                large: Number.parseInt(getComputedStyle(html).getPropertyValue("--break-large"), 10) || 1024,
                giant: Number.parseInt(getComputedStyle(html).getPropertyValue("--break-giant"), 10) || 1200,
                huge: Number.parseInt(getComputedStyle(html).getPropertyValue("--break-huge"), 10) || 1400,
                full: Number.parseInt(getComputedStyle(html).getPropertyValue("--break-full"), 10) || 1600,
                cut: Number.parseInt(getComputedStyle(html).getPropertyValue("--break-cut"), 10) || 1920
            };
            // Hilfsfunktion (intern im Effect nutzbar)
            const isBreakpointActive = {
                "Basics.useEffect.isBreakpointActive": (name)=>{
                    return window.innerWidth >= breakpoints[name];
                }
            }["Basics.useEffect.isBreakpointActive"];
            // --- 3. Scroll Logic (Header & State) ---
            let lastScrollTop = 0;
            const onScroll = {
                "Basics.useEffect.onScroll": ()=>{
                    const scrollTop = window.pageYOffset || html.scrollTop;
                    // Richtungserkennung (Scroll-Up / Scroll-Down)
                    if (scrollTop > lastScrollTop && scrollTop > 50) {
                        html.classList.add("scrolling-down");
                        html.classList.remove("scrolling-up");
                    } else if (scrollTop < lastScrollTop) {
                        html.classList.remove("scrolling-down");
                        html.classList.add("scrolling-up");
                    }
                    // Status am Seitenanfang
                    if (scrollTop <= 0) {
                        html.classList.remove("scrolling-up", "scrolled", "scrolling-down");
                    } else {
                        html.classList.add("scrolled");
                    }
                    lastScrollTop = scrollTop;
                }
            }["Basics.useEffect.onScroll"];
            // Event Listener hinzufügen
            window.addEventListener("scroll", onScroll, {
                passive: true
            });
            applyDeviceClasses();
            // Cleanup beim Unmount
            return ({
                "Basics.useEffect": ()=>{
                    window.removeEventListener("scroll", onScroll);
                }
            })["Basics.useEffect"];
        }
    }["Basics.useEffect"], []);
    return null;
};
_s(Basics, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = Basics;
const __TURBOPACK__default__export__ = Basics;
var _c;
__turbopack_context__.k.register(_c, "Basics");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/_module/scrollToTop.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ScrollToTop
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$_module$2f$smoothScroll$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/_module/smoothScroll.tsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ScrollToTop() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ScrollToTop.useEffect": ()=>{
            const lenis = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$_module$2f$smoothScroll$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLenis"])();
            if (lenis) {
                lenis.scrollTo(0, {
                    duration: 0.5,
                    easing: {
                        "ScrollToTop.useEffect": (t)=>t
                    }["ScrollToTop.useEffect"]
                });
            }
        }
    }["ScrollToTop.useEffect"], [
        pathname
    ]);
    return null;
}
_s(ScrollToTop, "V/ldUoOTYUs0Cb2F6bbxKSn7KxI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = ScrollToTop;
var _c;
__turbopack_context__.k.register(_c, "ScrollToTop");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/_module/pageLoader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PageLoader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function PageLoader() {
    _s();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [visible, setVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); // für Fade-In/Fade-Out
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PageLoader.useEffect": ()=>{
            const handleClick = {
                "PageLoader.useEffect.handleClick": (e)=>{
                    const target = e.target;
                    const link = target.closest("a[href]");
                    if (link && link.href.startsWith(window.location.origin)) {
                        const href = link.getAttribute("href");
                        if (href && (href.startsWith("#") || href.includes("#"))) return;
                        setLoading(true);
                        setVisible(true);
                        const minLoadingTime = 1000; // ms
                        setTimeout({
                            "PageLoader.useEffect.handleClick": ()=>setVisible(false)
                        }["PageLoader.useEffect.handleClick"], minLoadingTime); // Fade-Out starten
                        setTimeout({
                            "PageLoader.useEffect.handleClick": ()=>setLoading(false)
                        }["PageLoader.useEffect.handleClick"], minLoadingTime + 300); // nach Fade-Out komplett entfernen
                    }
                }
            }["PageLoader.useEffect.handleClick"];
            document.addEventListener("click", handleClick);
            return ({
                "PageLoader.useEffect": ()=>document.removeEventListener("click", handleClick)
            })["PageLoader.useEffect"];
        }
    }["PageLoader.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "page-loader ".concat(visible ? "visible" : "")
        }, void 0, false, {
            fileName: "[project]/app/assets/TypeScript/_module/pageLoader.tsx",
            lineNumber: 34,
            columnNumber: 9
        }, this)
    }, void 0, false);
}
_s(PageLoader, "jEQksFmZ+/eNoBhmRZo3NpplnQ4=");
_c = PageLoader;
var _c;
__turbopack_context__.k.register(_c, "PageLoader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/_module/aos.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AOSProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function AOSProvider(param) {
    let { children, disableOnMobile = true } = param;
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AOSProvider.useEffect": ()=>{
            let aos;
            const initAOS = {
                "AOSProvider.useEffect.initAOS": async ()=>{
                    const AOS = (await __turbopack_context__.A("[project]/node_modules/aos/dist/aos.js [app-client] (ecmascript, async loader)")).default;
                    AOS.init({
                        duration: 1200,
                        once: true,
                        offset: 100,
                        delay: 0,
                        disable: {
                            "AOSProvider.useEffect.initAOS": ()=>window.innerWidth < 1024
                        }["AOSProvider.useEffect.initAOS"],
                        startEvent: "DOMContentLoaded"
                    });
                    AOS.refresh();
                    aos = AOS;
                }
            }["AOSProvider.useEffect.initAOS"];
            // ⏱️ erst nach Paint / Idle
            if ("requestIdleCallback" in window) {
                requestIdleCallback(initAOS);
            } else {
                setTimeout(initAOS, 200);
            }
            return ({
                "AOSProvider.useEffect": ()=>{
                    var _aos_refreshHard;
                    aos === null || aos === void 0 ? void 0 : (_aos_refreshHard = aos.refreshHard) === null || _aos_refreshHard === void 0 ? void 0 : _aos_refreshHard.call(aos);
                }
            })["AOSProvider.useEffect"];
        }
    }["AOSProvider.useEffect"], [
        disableOnMobile
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
}
_s(AOSProvider, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = AOSProvider;
var _c;
__turbopack_context__.k.register(_c, "AOSProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/lib/config/site-config.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "siteConfig",
    ()=>siteConfig
]);
const siteConfig = {
    company: {
        name: {
            name: "Firma",
            title: "Firmenname",
            text: "Nico Beyer"
        },
        address: {
            name: "Adresse",
            title: "Firmensitz",
            text: "Uerdinger Straße 122"
        },
        zip: {
            name: "PLZ",
            title: "Postleitzahl",
            text: "40668"
        },
        city: {
            name: "Ort",
            title: "Standort",
            text: "Meerbusch"
        },
        email: {
            name: "E-Mail",
            title: "Kontaktieren Sie mich via E-Mail",
            text: "info@nbeyer.tech",
            href: "mailto:info@nbeyer.tech"
        },
        phone: {
            name: "Telefon",
            title: "Rufen Sie uns an",
            text: "+49 123 4567890",
            href: "tel:+491234567890"
        }
    },
    social: {
        instagram: {
            name: "Instagram",
            title: "Besuchen Sie mich auf Instagram",
            text: "Instagram",
            href: "https://instagram.com/musterfirma"
        },
        facebook: {
            name: "Facebook",
            title: "Besuchen Sie mich auf Facebook",
            text: "Facebook",
            href: "https://facebook.com/musterfirma"
        },
        xing: {
            name: "Xing",
            title: "Besuchen Sie mich auf XING",
            text: "xing",
            href: "https://www.xing.com/profile/Nico_Beyer031219"
        },
        linkedin: {
            name: "LinkedIn",
            title: "Besuchen Sie mich auf LinkedIn",
            text: "linkedin",
            href: "https://de.linkedin.com/in/nico-beyer-1347a8377"
        }
    },
    imprint: {
        companyName: {
            name: "Firma",
            title: "Firmenname",
            text: "Musterfirma GmbH"
        },
        owner: {
            name: "Inhaber",
            title: "Inhaber des Unternehmens",
            text: "Nico Beyer"
        },
        address: {
            name: "Adresse",
            title: "Adresse",
            text: "Uerdinger Straße 122"
        },
        zip: {
            name: "PLZ",
            title: "Postleitzahl",
            text: "40668"
        },
        city: {
            name: "Ort",
            title: "Stadt",
            text: "Meerbusch"
        },
        email: {
            name: "E-Mail",
            title: "Kontakt E-Mail",
            text: "info@nbeyer.tech",
            href: "mailto:info@nbeyer.tech"
        },
        phone: {
            name: "Telefon",
            title: "Kontakt Telefon",
            text: "+49 123 4567890",
            href: "tel:+491234567890"
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/lib/backend/config-proxy.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createCompanyProxy",
    ()=>createCompanyProxy,
    "createConfigProxy",
    ()=>createConfigProxy,
    "createItemProxy",
    ()=>createItemProxy
]);
function createItemProxy(item) {
    return new Proxy(item, {
        get (objItem, key) {
            if (typeof key === "symbol") return key === Symbol.toPrimitive ? ()=>objItem.text : undefined;
            if (key === "toString") return ()=>objItem.text;
            var _key;
            return (_key = objItem[key]) !== null && _key !== void 0 ? _key : undefined;
        }
    });
}
function createConfigProxy(obj) {
    const proxied = {};
    for(const key in obj){
        proxied[key] = createItemProxy(obj[key]);
    }
    return proxied;
}
function createCompanyProxy(siteConfig) {
    return {
        ...createConfigProxy(siteConfig.company),
        ...createConfigProxy(siteConfig.social),
        imprint: createConfigProxy(siteConfig.imprint)
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/lib/backend/company.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "company",
    ()=>company
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$config$2f$site$2d$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/lib/config/site-config.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$config$2d$proxy$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/lib/backend/config-proxy.tsx [app-client] (ecmascript)");
;
;
const company = {
    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$config$2d$proxy$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createConfigProxy"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$config$2f$site$2d$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["siteConfig"].company),
    ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$config$2d$proxy$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createConfigProxy"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$config$2f$site$2d$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["siteConfig"].social),
    imprint: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$config$2d$proxy$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createConfigProxy"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$config$2f$site$2d$config$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["siteConfig"].imprint)
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/elements/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
function Button(param) {
    let { href, type = "button", title, className = "btn", children, disabled = false, target } = param;
    if (href) {
        // Wenn href vorhanden -> Link
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            title: title !== null && title !== void 0 ? title : children === null || children === void 0 ? void 0 : children.toString(),
            className: className,
            target: target,
            rel: target === "_blank" ? "noopener noreferrer" : undefined,
            children: children
        }, void 0, false, {
            fileName: "[project]/app/components/elements/button.tsx",
            lineNumber: 25,
            columnNumber: 7
        }, this);
    }
    // Andernfalls normaler Button für Formulare
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: type,
        title: title,
        className: className,
        disabled: disabled,
        children: children
    }, void 0, false, {
        fileName: "[project]/app/components/elements/button.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_c = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/lib/backend/company.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$elements$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/elements/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function Header() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    if (pathname !== "/") {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        role: "banner",
        id: "header",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col large-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                            className: "social-container",
                            "data-aos": "fade-right",
                            "data-aos-delay": "200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "Folge mir"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/header.tsx",
                                    lineNumber: 21,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "line"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/header.tsx",
                                    lineNumber: 22,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("address", {
                                    className: "socials",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "unstyled-list",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.href,
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    title: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.title,
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.text,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        src: "/assets/images/icons/".concat(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.text, ".svg"),
                                                        alt: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.text,
                                                        width: 36,
                                                        height: 36,
                                                        style: {
                                                            height: "auto"
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/header.tsx",
                                                        lineNumber: 28,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/header.tsx",
                                                    lineNumber: 26,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/header.tsx",
                                                lineNumber: 25,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.href,
                                                    target: "_blank",
                                                    rel: "noopener noreferrer",
                                                    title: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.title,
                                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.text,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        src: "/assets/images/icons/".concat(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.text, ".svg"),
                                                        alt: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.text,
                                                        width: 36,
                                                        height: 36,
                                                        style: {
                                                            height: "auto"
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/header.tsx",
                                                        lineNumber: 37,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/header.tsx",
                                                    lineNumber: 35,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/header.tsx",
                                                lineNumber: 34,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/header.tsx",
                                        lineNumber: 24,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/header.tsx",
                                    lineNumber: 23,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/header.tsx",
                            lineNumber: 20,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/header.tsx",
                        lineNumber: 19,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col large-7 giant-6 huge-5",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "header-container",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
                                    "data-aos": "fade-down",
                                    "data-aos-delay": "400",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "Hi! Ich bin"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/header.tsx",
                                            lineNumber: 51,
                                            columnNumber: 17
                                        }, this),
                                        "Nico Beyer"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/header.tsx",
                                    lineNumber: 50,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "hr",
                                    "data-aos": "fade-right",
                                    "data-aos-delay": "600",
                                    "data-aos-duration": "1000"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/header.tsx",
                                    lineNumber: 55,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    "data-aos": "fade-up",
                                    "data-aos-delay": "800",
                                    children: "Als Frontend-Entwickler liegt mein Schwerpunkt auf der Gestaltung moderner Websites und Onlineshops mit klarem Fokus auf Benutzererlebnis und Performance. Ich entwickle durchdachte, funktionale Lösungen, die Design und Technik sinnvoll verbinden."
                                }, void 0, false, {
                                    fileName: "[project]/app/components/header.tsx",
                                    lineNumber: 57,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    "data-aos": "zoom-in",
                                    "data-aos-delay": "1000",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$elements$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/profil",
                                        title: "Mehr über mich und meine Arbeit erfahren",
                                        children: "Lernen Sie mich kennen"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/header.tsx",
                                        lineNumber: 62,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/header.tsx",
                                    lineNumber: 61,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/header.tsx",
                            lineNumber: 49,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/header.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/header.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                className: "pointer-nav",
                children: [
                    {
                        id: "#main",
                        num: "1",
                        text: "Einblick",
                        title: "Mehr über mich"
                    },
                    {
                        id: "#workflow",
                        num: "2",
                        text: "Workflow",
                        title: "Workflow anzeigen"
                    },
                    {
                        id: "#onlineshops",
                        num: "3",
                        text: "Onlineshops",
                        title: "Shop erstellung"
                    },
                    {
                        id: "#kontaktform",
                        num: "4",
                        text: "Kontaktformular",
                        title: "Zum Kontaktformular"
                    }
                ].map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        href: item.id,
                        className: "pointer-nav-item",
                        "data-aos": "fade-left",
                        "data-aos-delay": 1200 + index * 100,
                        title: item.title,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: item.num
                            }, void 0, false, {
                                fileName: "[project]/app/components/header.tsx",
                                lineNumber: 85,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: item.text
                            }, void 0, false, {
                                fileName: "[project]/app/components/header.tsx",
                                lineNumber: 86,
                                columnNumber: 13
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/app/components/header.tsx",
                        lineNumber: 77,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/components/header.tsx",
                lineNumber: 70,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                className: "scroll-down lazy-bg",
                href: "#main",
                title: "Zum Hauptbereich",
                "data-aos": "fade-up",
                "data-aos-delay": "1600",
                children: "Weiterlesen"
            }, void 0, false, {
                fileName: "[project]/app/components/header.tsx",
                lineNumber: 91,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/header.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_s(Header, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/form/FormCaptcha.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Captcha
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function Captcha(param) {
    let { onChange } = param;
    _s();
    const [captchaOptions, setCaptchaOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [captchaQuestion, setCaptchaQuestion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedCaptcha, setSelectedCaptcha] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [correctAnswer, setCorrectAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Captcha generieren: 3 Buttons, +-5 des korrekten Ergebnisses
    function generateCaptcha() {
        const a = Math.floor(Math.random() * 10) + 1;
        const b = Math.floor(Math.random() * 10) + 1;
        const correct = a + b;
        const options = [
            correct
        ];
        while(options.length < 3){
            const option = correct + Math.floor(Math.random() * 11) - 5;
            if (!options.includes(option) && option > 0) options.push(option);
        }
        setCaptchaQuestion("Wie viel ergibt: ".concat(a, " + ").concat(b, "?"));
        setCaptchaOptions(shuffleArray(options));
        setCorrectAnswer(correct);
        setSelectedCaptcha(null);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Captcha.useEffect": ()=>{
            generateCaptcha();
        }
    }["Captcha.useEffect"], []);
    function shuffleArray(arr) {
        return arr.sort(()=>Math.random() - 0.5);
    }
    function handleSelect(option) {
        setSelectedCaptcha(option);
        if (onChange) onChange(option);
    }
    function validate() {
        return selectedCaptcha === correctAnswer;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "captcha",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                children: captchaQuestion
            }, void 0, false, {
                fileName: "[project]/app/components/form/FormCaptcha.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "captcha-options",
                children: captchaOptions.map((opt)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: "".concat(selectedCaptcha === opt ? "active" : "", " no-btn"),
                        onClick: ()=>handleSelect(opt),
                        children: opt
                    }, opt, false, {
                        fileName: "[project]/app/components/form/FormCaptcha.tsx",
                        lineNumber: 55,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/components/form/FormCaptcha.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/form/FormCaptcha.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
_s(Captcha, "J89WRCSYgsQNcDW9uXjBPHQILIk=");
_c = Captcha;
var _c;
__turbopack_context__.k.register(_c, "Captcha");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/form/form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$elements$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/elements/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$form$2f$FormCaptcha$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/form/FormCaptcha.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ContactForm(param) {
    let {} = param;
    _s();
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [captchaValue, setCaptchaValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const isContactPage = pathname === '/kontakt';
    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);
        setStatus(null);
        const formData = new FormData(e.currentTarget);
        const body = Object.fromEntries(formData.entries());
        // Captcha prüfen
        if (!captchaValue) {
            setStatus("Bitte Captcha auswählen!");
            setLoading(false);
            return;
        }
        try {
            const res = await fetch("/api/send", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(body)
            });
            if (res.ok) {
                setStatus("Nachricht erfolgreich gesendet!");
                e.currentTarget.reset();
                setCaptchaValue(null);
            }
        } catch (e) {
        // Fehler ignorieren
        } finally{
            setLoading(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        className: "form",
        onSubmit: handleSubmit,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "row",
            children: [
                !isContactPage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
                    className: "col form-headline",
                    children: "Nehmen Sie mit mir Kontakt auf"
                }, void 0, false, {
                    fileName: "[project]/app/components/form/form.tsx",
                    lineNumber: 58,
                    columnNumber: 21
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
                    className: "col large-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            htmlFor: "companyName",
                            children: [
                                "Firmenname ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                    children: "(Pflicht)"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/form/form.tsx",
                                    lineNumber: 64,
                                    columnNumber: 61
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 64,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            id: "companyName",
                            placeholder: "Ihr Firmenname",
                            name: "companyName",
                            required: true
                        }, void 0, false, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 65,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            htmlFor: "email",
                            children: [
                                "E-Mail ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                    children: "(Pflicht)"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/form/form.tsx",
                                    lineNumber: 67,
                                    columnNumber: 51
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 67,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "email",
                            id: "email",
                            placeholder: "Ihre E-Mail",
                            name: "email",
                            required: true
                        }, void 0, false, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 68,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            htmlFor: "phone",
                            children: [
                                "Telefon ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                    children: "(Pflicht)"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/form/form.tsx",
                                    lineNumber: 70,
                                    columnNumber: 52
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 70,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "tel",
                            id: "phone",
                            placeholder: "Ihre Telefonnummer",
                            name: "phone",
                            required: true
                        }, void 0, false, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 71,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/form/form.tsx",
                    lineNumber: 63,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
                    className: "col large-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            htmlFor: "message",
                            children: [
                                "Nachricht ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                    children: "(Pflicht)"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/form/form.tsx",
                                    lineNumber: 75,
                                    columnNumber: 56
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 75,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            id: "message",
                            placeholder: "Ihre Nachricht",
                            name: "message",
                            rows: 6,
                            required: true
                        }, void 0, false, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 76,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$form$2f$FormCaptcha$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            onChange: setCaptchaValue
                        }, void 0, false, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 79,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "checkbox-container",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "checkbox",
                                    id: "Datenschutz",
                                    name: "Datenschutz",
                                    required: true
                                }, void 0, false, {
                                    fileName: "[project]/app/components/form/form.tsx",
                                    lineNumber: 82,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "Datenschutz",
                                    children: [
                                        "Die ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/datenschutz",
                                            title: "Informationen zum Datenschutz lesen",
                                            target: "_blank",
                                            children: "Datenschutzerklärung"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/form/form.tsx",
                                            lineNumber: 89,
                                            columnNumber: 33
                                        }, this),
                                        " habe ich gelesen und akzeptiert."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/form/form.tsx",
                                    lineNumber: 88,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 81,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$elements$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            type: "submit",
                            disabled: loading,
                            children: loading ? "Senden..." : "Nachricht abschicken"
                        }, void 0, false, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 93,
                            columnNumber: 21
                        }, this),
                        status && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "notification",
                            onClick: ()=>setStatus(''),
                            children: status
                        }, void 0, false, {
                            fileName: "[project]/app/components/form/form.tsx",
                            lineNumber: 98,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/form/form.tsx",
                    lineNumber: 74,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/form/form.tsx",
            lineNumber: 55,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/form/form.tsx",
        lineNumber: 54,
        columnNumber: 9
    }, this);
}
_s(ContactForm, "Jk0wRNL8rjw+RI2WGHD2gonS/wU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = ContactForm;
var _c;
__turbopack_context__.k.register(_c, "ContactForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/lib/config/site-navigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// site-navigation.ts
// Zentrale Navigation-Konfiguration
__turbopack_context__.s([
    "footerNavigationConfig",
    ()=>footerNavigationConfig,
    "mainNavigationConfig",
    ()=>mainNavigationConfig
]);
const mainNavigationConfig = [
    {
        label: "Home",
        href: "/",
        description: "Zur Startseite und Übersicht gelangen"
    },
    {
        label: "Profil",
        href: "/profil",
        description: "Mehr über mich und meine Arbeit erfahren"
    },
    {
        label: "Referenzen",
        href: "/referenzen",
        description: "Meine Projekte und Arbeiten ansehen"
    },
    {
        label: "Kontakt",
        href: "/kontakt",
        description: "Kontaktieren Sie mich via E-Mail"
    }
];
const footerNavigationConfig = [
    {
        label: "Home",
        href: "/",
        description: "Zur Startseite und Übersicht gelangen"
    },
    {
        label: "Kontakt",
        href: "/kontakt",
        description: "Kontaktieren Sie mich per E-Mail"
    },
    {
        label: "Impressum",
        href: "/impressum",
        description: "Rechtliche Angaben und Informationen"
    },
    {
        label: "Datenschutz",
        href: "/datenschutz",
        description: "Informationen zum Datenschutz lesen"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NavigationBase",
    ()=>NavigationBase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
// Import der neuen Scroll-Funktion
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$_essentials$2f$basics$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/_essentials/basics.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function NavigationBase(param) {
    let { items, variant = "main", closeMobileMenuCallback } = param;
    var _this = this;
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [openDropdowns, setOpenDropdowns] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isMobileView, setIsMobileView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [hasMounted, setHasMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const navRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastScrollY = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0);
    const NAV_BREAK = 992;
    const isMain = variant === "main";
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NavigationBase.useEffect": ()=>{
            setHasMounted(true);
            setIsMobileView(window.innerWidth <= NAV_BREAK);
            const handleResize = {
                "NavigationBase.useEffect.handleResize": ()=>setIsMobileView(window.innerWidth <= NAV_BREAK)
            }["NavigationBase.useEffect.handleResize"];
            window.addEventListener("resize", handleResize);
            return ({
                "NavigationBase.useEffect": ()=>window.removeEventListener("resize", handleResize)
            })["NavigationBase.useEffect"];
        }
    }["NavigationBase.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NavigationBase.useEffect": ()=>{
            const handleClickOutside = {
                "NavigationBase.useEffect.handleClickOutside": (e)=>{
                    if (navRef.current && !navRef.current.contains(e.target)) closeAllDropdowns();
                }
            }["NavigationBase.useEffect.handleClickOutside"];
            const handleScroll = {
                "NavigationBase.useEffect.handleScroll": ()=>{
                    if (window.innerWidth <= NAV_BREAK) return;
                    const currentY = window.scrollY;
                    if (Math.abs(currentY - lastScrollY.current) > 250) {
                        closeAllDropdowns();
                        lastScrollY.current = currentY;
                    }
                }
            }["NavigationBase.useEffect.handleScroll"];
            document.addEventListener("mousedown", handleClickOutside);
            window.addEventListener("scroll", handleScroll);
            return ({
                "NavigationBase.useEffect": ()=>{
                    document.removeEventListener("mousedown", handleClickOutside);
                    window.removeEventListener("scroll", handleScroll);
                }
            })["NavigationBase.useEffect"];
        }
    }["NavigationBase.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NavigationBase.useEffect": ()=>{
            if (navRef.current && isMain) {
                document.documentElement.style.setProperty("--navigation-height", "".concat(navRef.current.offsetHeight, "px"));
            }
        }
    }["NavigationBase.useEffect"], [
        isMain
    ]);
    const isActive = (href)=>href === "/" ? pathname === "/" : pathname.startsWith(href);
    const toggleDropdown = (href)=>setOpenDropdowns((prev)=>prev.includes(href) ? prev.filter((i)=>i !== href) : [
                ...prev,
                href
            ]);
    const closeDropdown = (href)=>setOpenDropdowns((prev)=>prev.filter((i)=>i !== href));
    const closeAllDropdowns = ()=>setOpenDropdowns([]);
    const closeMobileMenu = ()=>{
        setIsOpen(false);
        closeAllDropdowns();
        closeMobileMenuCallback === null || closeMobileMenuCallback === void 0 ? void 0 : closeMobileMenuCallback();
    };
    const focusParent = (href)=>{
        const selector = isMobileView ? '.navigation__mobile [data-trigger="'.concat(href, '"]') : '[data-trigger="'.concat(href, '"]');
        const parent = document.querySelector(selector);
        parent === null || parent === void 0 ? void 0 : parent.focus();
    };
    const handleParentKeyDown = (e, item)=>{
        var _item_children;
        const hasChildren = !!((_item_children = item.children) === null || _item_children === void 0 ? void 0 : _item_children.length);
        if (!hasChildren) return;
        const isOpen = openDropdowns.includes(item.href);
        if ([
            "Enter",
            " "
        ].includes(e.key)) {
            e.preventDefault();
            toggleDropdown(item.href);
        } else if (e.key === "Escape" && isOpen) {
            e.preventDefault();
            closeDropdown(item.href);
        } else if (e.key === "Tab" && isOpen) {
            setTimeout(()=>{
                const container = document.querySelector('[data-parent="'.concat(item.href, '"]'));
                const first = container === null || container === void 0 ? void 0 : container.querySelector(".nav-dropdown__link");
                first === null || first === void 0 ? void 0 : first.focus();
            }, 0);
        }
    };
    const handleChildKeyDown = function(e, item) {
        let isLastChild = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
        const container = document.querySelector('[data-parent="'.concat(item.href, '"]'));
        if (!container) return;
        const links = Array.from(container.querySelectorAll(".nav-dropdown__link"));
        if (!links.length) return;
        const current = e.target;
        const idx = links.indexOf(current);
        const isFirst = idx === 0;
        const isLast = idx === links.length - 1;
        if (e.key === "Escape" || e.key === "Tab" && (e.shiftKey && isFirst || !e.shiftKey && (isLast || isMobileView && isLastChild))) {
            e.preventDefault();
            focusParent(item.href);
            closeDropdown(item.href);
        }
    };
    const handleMobileMenuKeyDown = (e)=>{
        if (!isMobileView || !isOpen) return;
        if (e.key === "Escape") {
            e.preventDefault();
            closeMobileMenu();
            setTimeout(()=>{
                var _document_querySelector;
                return (_document_querySelector = document.querySelector(".navigation__toggle")) === null || _document_querySelector === void 0 ? void 0 : _document_querySelector.focus();
            }, 0);
        }
        if (e.key === "Tab" && !e.shiftKey) {
            const items = Array.from(document.querySelectorAll(".navigation__menu--mobile .nav-link, .navigation__menu--mobile .nav-link--span"));
            if (document.activeElement === items[items.length - 1]) {
                e.preventDefault();
                closeMobileMenu();
                setTimeout(()=>{
                    var _document_querySelector;
                    return (_document_querySelector = document.querySelector(".navigation__toggle")) === null || _document_querySelector === void 0 ? void 0 : _document_querySelector.focus();
                }, 0);
            }
        }
    };
    const renderNavItem = function(item) {
        let level = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
        var _item_children;
        const hasChildren = !!((_item_children = item.children) === null || _item_children === void 0 ? void 0 : _item_children.length);
        const isDropdownOpen = openDropdowns.includes(item.href);
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
            className: "nav-item ".concat(level > 0 ? "nav-item--nested" : "", " ").concat(hasChildren ? "sub" : ""),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "nav-item__wrapper",
                    children: hasChildren ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        role: "button",
                        tabIndex: 0,
                        "data-trigger": item.href,
                        "aria-expanded": isDropdownOpen,
                        "aria-haspopup": "true",
                        title: item.description || item.label,
                        className: "nav-link nav-link--span ".concat(isActive(item.href) ? "nav-link--active" : ""),
                        onClick: ()=>toggleDropdown(item.href),
                        onKeyDown: (e)=>handleParentKeyDown(e, item),
                        children: item.label
                    }, void 0, false, {
                        fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                        lineNumber: 160,
                        columnNumber: 13
                    }, _this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: item.href,
                        className: "nav-link ".concat(isActive(item.href) ? "nav-link--active" : ""),
                        title: item.description || item.label,
                        onClick: closeMobileMenu,
                        children: item.label
                    }, void 0, false, {
                        fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                        lineNumber: 174,
                        columnNumber: 13
                    }, _this)
                }, void 0, false, {
                    fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                    lineNumber: 158,
                    columnNumber: 9
                }, _this),
                hasChildren && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                    className: "nav-dropdown ".concat(isDropdownOpen ? "nav-dropdown--open" : ""),
                    "data-parent": item.href,
                    inert: !isDropdownOpen,
                    children: [
                        isMobileView && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            className: "nav-dropdown__item nav-dropdown__item--close",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "nav-dropdown__close",
                                onClick: ()=>closeDropdown(item.href),
                                "aria-label": "Dropdown ".concat(item.label, " schließen"),
                                children: "✕ Schließen"
                            }, void 0, false, {
                                fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                                lineNumber: 193,
                                columnNumber: 17
                            }, _this)
                        }, void 0, false, {
                            fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                            lineNumber: 192,
                            columnNumber: 15
                        }, _this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                            className: "nav-dropdown__item nav-dropdown__item--parent",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: item.href,
                                tabIndex: isDropdownOpen ? 0 : -1,
                                className: "nav-dropdown__link ".concat(isActive(item.href) ? "nav-dropdown__link--active" : ""),
                                "data-parent": item.href,
                                onKeyDown: (e)=>handleChildKeyDown(e, item),
                                onClick: closeMobileMenu,
                                children: "Übersicht"
                            }, void 0, false, {
                                fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                                lineNumber: 204,
                                columnNumber: 15
                            }, _this)
                        }, void 0, false, {
                            fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                            lineNumber: 203,
                            columnNumber: 13
                        }, _this),
                        item.children.map((child, idx, arr)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                className: "nav-dropdown__item",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: child.href,
                                    tabIndex: isDropdownOpen ? 0 : -1,
                                    className: "nav-dropdown__link ".concat(isActive(child.href) ? "nav-dropdown__link--active" : ""),
                                    "data-parent": item.href,
                                    onKeyDown: (e)=>handleChildKeyDown(e, item, idx === arr.length - 1),
                                    onClick: closeMobileMenu,
                                    children: child.label
                                }, void 0, false, {
                                    fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                                    lineNumber: 218,
                                    columnNumber: 17
                                }, _this)
                            }, child.href, false, {
                                fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                                lineNumber: 217,
                                columnNumber: 15
                            }, _this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                    lineNumber: 186,
                    columnNumber: 11
                }, _this)
            ]
        }, item.href, true, {
            fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
            lineNumber: 157,
            columnNumber: 7
        }, _this);
    };
    if (!isMain) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
            role: "navigation",
            "aria-label": "Footer Navigation",
            className: "footer-navigation",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "navigation__menu navigation__menu--footer",
                children: items.map(renderNavItem)
            }, void 0, false, {
                fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                lineNumber: 239,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
            lineNumber: 238,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "navigation__container",
        ref: navRef,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "navigation__header",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "navigation__logo",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/",
                            className: "navigation__logo-link",
                            title: "Zur Startseite gelangen",
                            onClick: (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$_essentials$2f$basics$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["handleLogoScroll"])(e, pathname),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: "/assets/images/layout/icon.svg",
                                alt: "Logo",
                                width: 60,
                                height: "auto"
                            }, void 0, false, {
                                fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                                lineNumber: 255,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                            lineNumber: 249,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                        lineNumber: 247,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        role: "navigation",
                        "aria-label": "Hauptnavigation",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                            className: "navigation__menu navigation__menu--desktop",
                            children: items.map(renderNavItem)
                        }, void 0, false, {
                            fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                            lineNumber: 260,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                        lineNumber: 259,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "navigation__toggle no-btn",
                        onClick: ()=>setIsOpen(!isOpen),
                        "aria-label": isOpen ? "Menü schließen" : "Menü öffnen",
                        "aria-expanded": isOpen,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "hamburger ".concat(isOpen ? "hamburger--open" : ""),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "hamburger__line"
                                }, void 0, false, {
                                    fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                                    lineNumber: 270,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "hamburger__line"
                                }, void 0, false, {
                                    fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                                    lineNumber: 271,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "hamburger__line"
                                }, void 0, false, {
                                    fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                                    lineNumber: 272,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                            lineNumber: 269,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                        lineNumber: 263,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                lineNumber: 246,
                columnNumber: 7
            }, this),
            hasMounted && isOpen && isMobileView && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "navigation__overlay",
                onClick: closeMobileMenu
            }, void 0, false, {
                fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                lineNumber: 277,
                columnNumber: 48
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "navigation__mobile ".concat(isOpen ? "navigation__mobile--open" : ""),
                onKeyDown: handleMobileMenuKeyDown,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                    className: "navigation__menu navigation__menu--mobile",
                    children: items.map(renderNavItem)
                }, void 0, false, {
                    fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                    lineNumber: 283,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
                lineNumber: 279,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx",
        lineNumber: 245,
        columnNumber: 5
    }, this);
}
_s(NavigationBase, "vGElBbsWyqbbIKWpyndMVC9J7mY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = NavigationBase;
var _c;
__turbopack_context__.k.register(_c, "NavigationBase");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/navigation/footer-navigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FooterNavigation",
    ()=>FooterNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$config$2f$site$2d$navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/lib/config/site-navigation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$navigation$2d$base$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function FooterNavigation() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$navigation$2d$base$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationBase"], {
        items: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$config$2f$site$2d$navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["footerNavigationConfig"],
        variant: "footer"
    }, void 0, false, {
        fileName: "[project]/app/components/navigation/footer-navigation.tsx",
        lineNumber: 7,
        columnNumber: 10
    }, this);
}
_c = FooterNavigation;
var _c;
__turbopack_context__.k.register(_c, "FooterNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/footer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$form$2f$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/form/form.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/lib/backend/company.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$navigation$2f$footer$2d$navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/navigation/footer-navigation.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function Footer() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const isContactPage = pathname === '/kontakt';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "bg-color-dark",
        role: "contentinfo",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "row center",
                "data-aos": "fade-up",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col large-10",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "footer-wrapper",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "footer-branding",
                                "data-aos": "fade-up",
                                "data-aos-delay": "200",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    title: "Zur Startseite und Übersicht gelangen",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        className: "no-border",
                                        src: "/assets/images/layout/branding.svg",
                                        alt: "".concat(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].address.text, " - Logo"),
                                        width: 150,
                                        height: 24,
                                        style: {
                                            width: "auto",
                                            height: "auto"
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/footer.tsx",
                                        lineNumber: 23,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/footer.tsx",
                                    lineNumber: 22,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/footer.tsx",
                                lineNumber: 21,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "trenner"
                            }, void 0, false, {
                                fileName: "[project]/app/components/footer.tsx",
                                lineNumber: 27,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "email",
                                "data-aos": "fade-up",
                                "data-aos-delay": "400",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: "E-Mail:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/footer.tsx",
                                        lineNumber: 31,
                                        columnNumber: 15
                                    }, this),
                                    " ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].email.href,
                                        title: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].email.title,
                                        children: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].email.text
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/footer.tsx",
                                        lineNumber: 32,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/footer.tsx",
                                lineNumber: 30,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "trenner"
                            }, void 0, false, {
                                fileName: "[project]/app/components/footer.tsx",
                                lineNumber: 37,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "social-container",
                                "data-aos": "fade-up",
                                "data-aos-delay": "600",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.href,
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                title: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.title,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.text,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    src: "/assets/images/icons/".concat(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.text, ".svg"),
                                                    alt: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].xing.text,
                                                    width: 24,
                                                    height: 24,
                                                    style: {
                                                        height: "auto"
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/footer.tsx",
                                                    lineNumber: 44,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/footer.tsx",
                                                lineNumber: 43,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/footer.tsx",
                                            lineNumber: 42,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.href,
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                title: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.title,
                                                className: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.text,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    src: "/assets/images/icons/".concat(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.text, ".svg"),
                                                    alt: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$company$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["company"].linkedin.text,
                                                    width: 24,
                                                    height: 24,
                                                    style: {
                                                        height: "auto"
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/footer.tsx",
                                                    lineNumber: 49,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/footer.tsx",
                                                lineNumber: 48,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/footer.tsx",
                                            lineNumber: 47,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/footer.tsx",
                                    lineNumber: 41,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/footer.tsx",
                                lineNumber: 40,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/footer.tsx",
                        lineNumber: 19,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/footer.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/footer.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            !isContactPage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "row center",
                id: "kontaktform",
                "data-aos": "zoom-in-up",
                "data-aos-duration": "1000",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$form$2f$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/app/components/footer.tsx",
                        lineNumber: 62,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/footer.tsx",
                    lineNumber: 61,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/footer.tsx",
                lineNumber: 60,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$navigation$2f$footer$2d$navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FooterNavigation"], {}, void 0, false, {
                fileName: "[project]/app/components/footer.tsx",
                lineNumber: 69,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/footer.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_s(Footer, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = Footer;
var _c;
__turbopack_context__.k.register(_c, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/assets/TypeScript/_module/lazyLoad.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const LazyLoad = (param)=>{
    let { children, offset = "200px", threshold = 0.1 } = param;
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])(); // Nur im Client verfügbar
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LazyLoad.useEffect": ()=>{
            const loadBackgroundImage = {
                "LazyLoad.useEffect.loadBackgroundImage": (element)=>{
                    const bgSrc = element.getAttribute("data-bg-src");
                    const bgSrcset = element.getAttribute("data-bg-srcset");
                    if (bgSrc || bgSrcset) {
                        if (bgSrcset) {
                            element.setAttribute("style", "background-image: image-set(url(".concat(bgSrcset, ") 1x);"));
                        } else if (bgSrc) {
                            element.setAttribute("style", "background-image: url(".concat(bgSrc, ");"));
                        }
                    }
                }
            }["LazyLoad.useEffect.loadBackgroundImage"];
            const observer = new IntersectionObserver({
                "LazyLoad.useEffect": (entries, obs)=>{
                    entries.forEach({
                        "LazyLoad.useEffect": (entry)=>{
                            if (!entry.isIntersecting) return;
                            const elem = entry.target;
                            elem.classList.add("lazy-processing", "is-on-screen");
                            if (elem.classList.contains("lazy-bg") || elem.hasAttribute("data-bg-src") || elem.hasAttribute("data-bg-srcset")) {
                                loadBackgroundImage(elem);
                                elem.classList.add("lazy-loaded");
                                observer.unobserve(elem);
                                return;
                            }
                            const loadedCallbackTarget = elem.nodeName !== "PICTURE" ? elem : elem.querySelector("img");
                            if (loadedCallbackTarget) {
                                const handleLoad = {
                                    "LazyLoad.useEffect.handleLoad": (e)=>{
                                        const target = e.target;
                                        target.classList.add("lazy-loaded");
                                    }
                                }["LazyLoad.useEffect.handleLoad"];
                                if (elem.nodeName === "IMG" || elem.nodeName === "IFRAME") {
                                    loadedCallbackTarget.addEventListener("load", handleLoad);
                                    loadedCallbackTarget.addEventListener("error", {
                                        "LazyLoad.useEffect": ()=>{
                                            loadedCallbackTarget.classList.add("lazy-loaded");
                                        }
                                    }["LazyLoad.useEffect"]);
                                } else {
                                    loadedCallbackTarget.classList.add("lazy-loaded");
                                }
                            }
                            if (elem.nodeName === "PICTURE") {
                                const childs = elem.querySelectorAll("img, source");
                                childs.forEach({
                                    "LazyLoad.useEffect": (child)=>{
                                        if (child.hasAttribute("data-src")) {
                                            child.setAttribute("src", child.getAttribute("data-src"));
                                        }
                                        if (child.hasAttribute("data-srcset")) {
                                            child.setAttribute("srcset", child.getAttribute("data-srcset"));
                                        }
                                    }
                                }["LazyLoad.useEffect"]);
                            } else if (elem.nodeName === "IMG") {
                                const imgElem = elem;
                                if (imgElem.hasAttribute("data-srcset")) {
                                    imgElem.srcset = imgElem.getAttribute("data-srcset");
                                }
                                if (imgElem.hasAttribute("data-src")) {
                                    imgElem.src = imgElem.getAttribute("data-src");
                                }
                            } else if (elem.nodeName === "IFRAME") {
                                const iframeElem = elem;
                                iframeElem.src = iframeElem.getAttribute("data-src");
                            } else {
                                elem.classList.add("lazy-loaded");
                            }
                            observer.unobserve(elem);
                        }
                    }["LazyLoad.useEffect"]);
                }
            }["LazyLoad.useEffect"], {
                rootMargin: offset,
                threshold: threshold
            });
            // Beobachtete Elemente
            const nodes = [
                ...document.querySelectorAll(".lazy-image, .lazy-bg, .lazy-iframe, .lazy-content")
            ];
            nodes.forEach({
                "LazyLoad.useEffect": (node)=>{
                    observer.observe(node);
                }
            }["LazyLoad.useEffect"]);
            return ({
                "LazyLoad.useEffect": ()=>{
                    observer.disconnect();
                }
            })["LazyLoad.useEffect"];
        }
    }["LazyLoad.useEffect"], [
        pathname,
        offset,
        threshold
    ]); // Denke daran, dass `pathname` die Router-Informationen enthält.
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
};
_s(LazyLoad, "V/ldUoOTYUs0Cb2F6bbxKSn7KxI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = LazyLoad;
const __TURBOPACK__default__export__ = LazyLoad;
var _c;
__turbopack_context__.k.register(_c, "LazyLoad");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/navigation/main-navigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MainNavigation",
    ()=>MainNavigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$config$2f$site$2d$navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/lib/config/site-navigation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$navigation$2d$base$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/lib/backend/navigation-base.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function MainNavigation() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$backend$2f$navigation$2d$base$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationBase"], {
        items: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$lib$2f$config$2f$site$2d$navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mainNavigationConfig"],
        variant: "main"
    }, void 0, false, {
        fileName: "[project]/app/components/navigation/main-navigation.tsx",
        lineNumber: 7,
        columnNumber: 10
    }, this);
}
_c = MainNavigation;
var _c;
__turbopack_context__.k.register(_c, "MainNavigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/ClientLayout.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ClientLayout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
// import Navigation from "./components/elements/navigation";
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$elements$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/elements/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/footer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$_module$2f$lazyLoad$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/assets/TypeScript/_module/lazyLoad.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$navigation$2f$main$2d$navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/navigation/main-navigation.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
// 🔐 Login global aktiv/deaktiviert (Client-seitig verfügbar)
const LOGIN_ENABLED = ("TURBOPACK compile-time value", "false") === "true";
function ClientLayout(param) {
    let { children, customBodyClass } = param;
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const [loggedIn, setLoggedIn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ClientLayout.useEffect": ()=>{
            const body = document.body;
            let classes = [];
            if (customBodyClass) {
                classes.push(customBodyClass);
            } else if (!pathname || pathname === "/") {
                classes = [
                    "index"
                ];
            } else {
                const segments = pathname.split("/").filter(Boolean);
                classes.push(...segments);
                if (segments.length >= 2) {
                    for(let i = 1; i < segments.length; i++){
                        classes.push("".concat(segments[i - 1], "-").concat(segments[i]));
                    }
                }
            }
            body.className = classes.join(" ");
            // ✅ Login-Status bestimmen
            if ("TURBOPACK compile-time truthy", 1) {
                // Login-Schutz deaktiviert → immer "eingeloggt"
                setLoggedIn(true);
            } else //TURBOPACK unreachable
            ;
            return ({
                "ClientLayout.useEffect": ()=>{
                    body.className = "";
                }
            })["ClientLayout.useEffect"];
        }
    }["ClientLayout.useEffect"], [
        pathname,
        customBodyClass
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            loggedIn && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "navigation",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "row",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$navigation$2f$main$2d$navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MainNavigation"], {}, void 0, false, {
                            fileName: "[project]/app/ClientLayout.tsx",
                            lineNumber: 67,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/ClientLayout.tsx",
                        lineNumber: 66,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/ClientLayout.tsx",
                    lineNumber: 65,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/ClientLayout.tsx",
                lineNumber: 64,
                columnNumber: 9
            }, this),
            loggedIn && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/ClientLayout.tsx",
                lineNumber: 73,
                columnNumber: 20
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                id: "main",
                role: "main",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$assets$2f$TypeScript$2f$_module$2f$lazyLoad$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    offset: "200px",
                    threshold: 0.1,
                    children: children
                }, void 0, false, {
                    fileName: "[project]/app/ClientLayout.tsx",
                    lineNumber: 76,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/ClientLayout.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            loggedIn && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/ClientLayout.tsx",
                lineNumber: 81,
                columnNumber: 20
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$elements$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "back-to-top no-btn",
                title: "Zurück zum Start",
                "aria-label": "Zum Seitenanfang scrollen",
                children: "⇧"
            }, void 0, false, {
                fileName: "[project]/app/ClientLayout.tsx",
                lineNumber: 83,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ClientLayout, "XFYv6S6oC3NKcxjo3J6rA1ADwgw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = ClientLayout;
var _c;
__turbopack_context__.k.register(_c, "ClientLayout");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_07c21204._.js.map