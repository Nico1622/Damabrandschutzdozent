(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_aos_dist_aos_20d5db71.js",
  "static/chunks/app_07c21204._.js",
  "static/chunks/node_modules_4cd2fc9e._.js",
  "static/chunks/app_assets_scss_style_scss_b6463dc4.css"
],
    source: "dynamic"
});
