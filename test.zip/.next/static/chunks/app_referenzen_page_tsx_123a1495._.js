(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_swiper_59f80e81._.js",
  "static/chunks/app_79758e41._.js",
  "static/chunks/node_modules_swiper_swiper_81c11a6e.css"
],
    source: "dynamic"
});
