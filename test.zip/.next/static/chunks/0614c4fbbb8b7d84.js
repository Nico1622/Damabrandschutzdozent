__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/1cff069241111374.js",
  "static/chunks/turbopack-7df80c4f3cc66850.js"
])
