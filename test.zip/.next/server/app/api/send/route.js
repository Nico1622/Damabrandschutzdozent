var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send/route.js")
R.c("server/chunks/node_modules_@react-email_render_dist_node_index_mjs_1bf9c5b5._.js")
R.c("server/chunks/node_modules_2c3ad747._.js")
R.c("server/chunks/[root-of-the-server]__9e9cbab9._.js")
R.m("[project]/.next-internal/server/app/api/send/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/send/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/send/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
