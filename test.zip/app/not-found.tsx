export const metadata = {
  title: "404 – Diese Seite gibt es nicht",
  description: "Oops! Diese Seite existiert leider nicht (mehr). Nutze die Navigation oder kehre zur Startseite zurück.",
};


import Link from "next/link";

export default function NotFoundPage() {
  return (
    <div className="pageWrap">
      <div className="row">
        <div className="col">
          <div
            className="notfound-container"
            data-aos="fade-up"
          >
            <h1
              className="notfound-title"
              data-aos="zoom-in"
              data-aos-delay="100"
            >
              404
            </h1>

            <p
              className="notfound-text"
              data-aos="fade-up"
              data-aos-delay="200"
            >
              Diese Seite konnte nicht gefunden werden.
            </p>

            <p
              className="notfound-subtext"
              data-aos="fade-up"
              data-aos-delay="300"
            >
              Vielleicht wurde sie verschoben oder gelöscht.
            </p>

            <div
              className="notfound-btn-wrapper"
              data-aos="fade-up"
              data-aos-delay="400"
            >
              <Link href="/" title="Weiter zur Startseite" className="btn">
                Zur Startseite
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

}
